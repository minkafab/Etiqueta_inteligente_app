# Etiqueta_inteligente_app
App Android para Etiquetas Inteligentes 
